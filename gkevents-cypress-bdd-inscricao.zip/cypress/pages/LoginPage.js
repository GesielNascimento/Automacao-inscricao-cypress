class LoginPage {
  visit() {
    cy.visit("/login");
  }

  login(email, senha) {
    this.visit();
    cy.get("#email").clear().type(email);
    cy.get("#password").clear().type(senha);
    cy.get("button[type='submit']").click();
    // Considera que sair da rota /login indica sucesso
    cy.url().should("not.include", "/login");
  }

  assertOnLoginPage() {
    cy.url().should("include", "/login");
    cy.contains(/entrar|login/i).should("be.visible");
  }
}

export default new LoginPage();