class EventDetailsPage {
  assertEventInfoVisible() {
    cy.get("h1, h2").should("be.visible");
    cy.contains(/data|local|descri(ç|c)[aã]o/i).should("exist");
  }

  assertEnrollVisible() {
    cy.contains(/inscrever-se|inscreva-se/i).should("be.visible");
  }

  assertEnrollNotVisible() {
    cy.contains(/inscrever-se|inscreva-se/i).should("not.exist");
  }

  clickEnroll() {
    cy.contains(/inscrever-se|inscreva-se/i).click();
  }

  confirmEnrollIfModal() {
    // caso exista um modal de confirmação
    cy.get("body").then(($b) => {
      if ($b.find(".modal, [role='dialog']").length) {
        cy.contains(".modal [type='submit'], [role='dialog'] button, .modal button", /confirmar|inscrever|ok|sim/i).click({ force: true });
      }
    });
  }

  assertSuccessToast(regex) {
    cy.contains(".toast, .alert-success, .text-green-600, .swal2-popup", regex).should("be.visible");
  }

  assertEnrolledStatus() {
    cy.contains(/inscrito|minha inscri(ç|c)[aã]o/i).should("exist");
    // ou botão de cancelar
    cy.contains(/cancelar inscri(ç|c)[aã]o/i).should("be.visible");
  }

  ensureEnrolled() {
    cy.get("body").then(($b) => {
      const cancelExists = $b.find("button, a").toArray().some(el => /cancelar inscri(ç|c)[aã]o/i.test(el.textContent || ""));
      if (!cancelExists) {
        this.clickEnroll();
        this.confirmEnrollIfModal();
        this.assertEnrolledStatus();
      }
    });
  }

  cancelEnroll() {
    cy.contains(/cancelar inscri(ç|c)[aã]o/i).click();
    // confirma se houver modal
    cy.get("body").then(($b) => {
      if ($b.find(".modal, [role='dialog']").length) {
        cy.contains(/confirmar|remover|sim|ok/i).click({ force: true });
      }
    });
  }

  assertClosedBadge() {
    cy.contains(/encerrado|finalizado|vencido/i).should("be.visible");
  }
}

export default new EventDetailsPage();