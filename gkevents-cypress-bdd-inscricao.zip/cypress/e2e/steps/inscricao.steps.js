import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
import HomePage from "../../pages/HomePage";
import LoginPage from "../../pages/LoginPage";
import EventDetailsPage from "../../pages/EventDetailsPage";

Given("que estou na página inicial pública", () => {
  HomePage.visit();
});

When('eu abro os detalhes do evento {string}', (titulo) => {
  HomePage.openEventByTitle(titulo);
});

Then("devo ver informações do evento", () => {
  EventDetailsPage.assertEventInfoVisible();
});

Then('devo ver a ação "Inscrever-se"', () => {
  EventDetailsPage.assertEnrollVisible();
});

When('eu tento me inscrever no evento {string} sem estar logado', (titulo) => {
  HomePage.openEventByTitle(titulo);
  EventDetailsPage.clickEnroll();
});

Then("devo ser redirecionado para a tela de login", () => {
  LoginPage.assertOnLoginPage();
});

Given('que estou autenticado como {string} com a senha {string}', (email, senha) => {
  LoginPage.login(email, senha);
});

Given('estou nos detalhes do evento {string}', (titulo) => {
  HomePage.visit();
  HomePage.openEventByTitle(titulo);
});

When("eu confirmo a inscrição", () => {
  EventDetailsPage.clickEnroll();
  EventDetailsPage.confirmEnrollIfModal();
});

Then('devo ver a mensagem "Inscrição realizada com sucesso"', () => {
  EventDetailsPage.assertSuccessToast(/inscri(ç|c)ão.*sucesso/i);
});

Then('o status do evento para mim deve ser "Inscrito"', () => {
  EventDetailsPage.assertEnrolledStatus();
});

Given('estou inscrito no evento {string}', (titulo) => {
  HomePage.visit();
  HomePage.openEventByTitle(titulo);
  EventDetailsPage.ensureEnrolled();
});

When("eu cancelo minha inscrição", () => {
  EventDetailsPage.cancelEnroll();
});

Then('devo ver a mensagem "Inscrição cancelada"', () => {
  EventDetailsPage.assertSuccessToast(/cancelada?/i);
});

Then('a ação "Inscrever-se" deve ficar disponível novamente', () => {
  EventDetailsPage.assertEnrollVisible();
});

Then('devo ver o status "Encerrado"', () => {
  EventDetailsPage.assertClosedBadge();
});

Then('não devo ver a ação "Inscrever-se"', () => {
  EventDetailsPage.assertEnrollNotVisible();
});