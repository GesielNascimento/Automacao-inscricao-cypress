class HomePage {
  visit() {
    cy.visit("/"); // ajuste se a home pública for outra rota
  }

  openEventByTitle(titulo) {
    // Procura um card de evento pelo título e clica em "Ver detalhes"
    cy.contains(".event-card, .card, .grid > div, article", titulo, { matchCase: false })
      .within(() => {
        cy.contains(/ver detalhes|detalhes|saiba mais/i).click();
      });
  }
}

export default new HomePage();